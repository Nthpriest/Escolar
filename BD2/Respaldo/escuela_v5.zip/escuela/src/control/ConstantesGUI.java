/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package control;

/**
 *Clase que contiene las operaciones por el usuario
 * @author IVI
 */
public class ConstantesGUI {

    /**
     * Stributo estatico agregar
     */
    public static int AGREGAR = 0;
    /**
     * Atributo estatico reemplazar
     */
    public static int REEMPLAZAR = 1;
    /**
     * Atributo estatico eliminar
     */
    public static int ELIMINAR = 2;
    /**
     * atributo estatico desplegar
     */
    public static int DESPLEGAR = 3;
      /**
     * representa, el apoderado
     */
    public static int APODERADO =4;
    /**
     * representa el padrino
     */
    public static int PADRINO = 5;
    /**
     * Atributo estatico aceptar
     */
    public static String ACEPTAR = "Aceptar";
    /**
     * Atributo estatico cancelar
     */
    public static String CANCELAR = "Cancelar";
    
    /**
     * Atributo estatico Aceptar
     */
    public static int ACTUALIZAR = 6;
    /**
     * atributo estatico Guardar
     */
    public static String GUARDAR="Guardar";
}
